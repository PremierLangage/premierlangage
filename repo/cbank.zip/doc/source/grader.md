# Les graders classiques plbank pour le langage C


## Comment ça marche

Un programme C contient toujours une seule fonction **main** qui
constitue le point d'entrée d'exécution du programme associé.


## Doctesting à la Python pour le C


## Comparaison par rapport à une solution enseignant



## Code contextuel et plongement du code étudiant

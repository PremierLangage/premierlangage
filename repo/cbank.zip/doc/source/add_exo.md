# Ajout d'un nouvel exercice de C dans plbank

## structuration d'un exercice Premier Langage pour le C



## Choisir les bons tags



## Choisir un grader



## Tester le nouvel exercice

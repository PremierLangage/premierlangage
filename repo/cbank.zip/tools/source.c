#include <stdio.h>

int main(int argc, char* argv[]){
int a;
int b;
int c;

a = 10;
b = 0;
c = (-1);
b = (1 * 2);
a += 10;
c = (0 + a);
if (a <= 1 + 1 / 2){
  b *= (-1);
}
a *= a;

printf("%d %d %d", a, b, c);
}
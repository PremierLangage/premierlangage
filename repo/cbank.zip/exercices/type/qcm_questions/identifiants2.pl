title=Identifiants en C

template=../plbank/gift/template/multiplechoices_template.pl
type=direct


build=@cbank:/exercices/type/qcm_questions/randomident.py

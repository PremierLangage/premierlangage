title=Les variables en C

template=../plbank/gift/template/multiplechoices_template.pl
type=direct
answer1=0
answer2=0.0
answer3='a'
answer4="FooBar"
answer5= -1
answer6= 33 + 10 
answer7=700
answer8=1234560

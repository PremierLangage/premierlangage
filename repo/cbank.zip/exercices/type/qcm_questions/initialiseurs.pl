include=@reponses.pl
text==

soit la déclaration de variable suivante :

	int x = ... ;

Quelles valeurs sont des initialisation **INcorrectes** de x ?

==

right_answer1=0.0
right_answer2="FooBar"


title=Les variables en C
type=direct
template=../plbank/gift/template/multiplechoices_template.pl
text==
Parmi les types suivants, lesquels sont des types C entiers.
==
answer1=int
answer2=float
answer3=unsigned char
answer4=double
answer5=long float
answer6=short
answer7=unsigned long int
answer8=long double
right_answer1=int
right_answer2=unsigned char
right_answer3=short
right_answer4=unsigned long int

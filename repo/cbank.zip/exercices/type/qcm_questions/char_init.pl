

template=cbank:/exercices/type/qcm_questions/reponses.pl
text==

soit la déclaration de variable suivante :

	char c = ... ;

Quelles valeurs sont des initialisation **INcorrectes** de c ?

==

answer1=0
answer2=0.0
answer3='a'
answer4="FooBar"
answer5= -1
answer6= 33 + 10 
answer7=700
answer8=1234560
right_answer1="FooBar"
right_answer2=0.0
right_anwser3=700
right_anwser4=1234560


feedback="Initialiser un float avec un entier, ne pose des problèmes que lorsqu'il est d'une longuer supérieur à la précision."
type=direct

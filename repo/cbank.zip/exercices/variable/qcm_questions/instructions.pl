title=Les instructions en C
text==
Qu'est ce qui caractérise une instruction en langage C
==
type=direct
template=../plbank/gift/template/multiplechoices_template.pl
answer1=Un identificateur, le nom de la variable.
answer2=Une couleur.
answer3=Un statut, libérée ou allouée.
answer4=Un type.
answer5=Un emplacement mémoire (sur la pile ou le tas...).
answer6=Une valeur.
answer7=Un Effet de Bord.
right_answer1=Un Effet de Bord.



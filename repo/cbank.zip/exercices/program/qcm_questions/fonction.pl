title=Les fonctions d'un programme C
text==
Selectionner les déclarations justes.
==
type=direct
template=../plbank/gift/template/multiplechoices_template.pl
answer1=Une fonction peut être appelée qu'une seule fois dans un programme.
answer2=Les fonctions d'un programme C peuvent s'appeler elle-même.
answer3=Une fonction jamais utilisée peut être otée des sources pour donner le même programme.
answer4=Deux fonctions peuvent porter le même nom si elles n'utilise pas les mêmes arguments.
answer5=Une fonction C a toujours un type de retour.
right_answer1=Les fonctions d'un programme C peuvent s'appeler elle-même.
right_answer2=Une fonction jamais utilisée peut être otée des sources pour donner le même programme.
right_answer3=Une fonction C a toujours un type de retour.

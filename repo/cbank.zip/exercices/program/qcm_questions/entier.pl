title=Déclaration d'une variable entière
text==
Selectionner les lignes déclarant une variable entière C.
==
type=direct
template=../plbank/gift/template/multiplechoices_template.pl
answer1=int i;
answer2=int j;
answer3=int 23;
answer4=char* "Paul";
answer5=float compteur;
answer6=int string;
answer7=float* entier;
right_answer1=int i;
right_answer2=int j;
right_answer3=int string;

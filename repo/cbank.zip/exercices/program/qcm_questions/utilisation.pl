title=Utilisation du langage C
text==
Selectionner les déclarations justes
==
type=direct
template=../plbank/gift/template/multiplechoices_template.pl
answer1=Le langage C est omniprésent pour faire des sites web.
answer2=La quasi totalité des systèmes d'explitation sont écrit en C.
answer3=Le langage C ne peut pas utiliser plus de 50% des capacités d'un ordinateur.
answer4=Le langage C est pratique pour dévelloper des applications mobiles.
answer5=Beaucoup de calculs haute performance sont fait en C.
answer6=Uniquement les machines sous Linux peuvent exécuté les programmes C.
answer7=Le langage C est réputé pour produire des programmes efficaces.
right_answer1=La quasi totalité des systèmes d'explitation sont écrit en C.
right_answer2=Beaucoup de calculs haute performance sont fait en C.
right_answer3=Le langage C est réputé pour produire des programmes efficaces.

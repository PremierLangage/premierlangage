title=Structuration d'un programme C
text==
Selectionner les déclarations justes
==
type=direct
template=../plbank/gift/template/multiplechoices_template.pl
answer1=Un programme C est composé de classes modélisant des objets.
answer2=Un programme C est une collection de fonctions qui s'articulent autour d'un main.
answer3=Le langage C est un langage fonctionnel.
answer4=Le langage C utilise principalement des balises ouvrantes et fermantes.
answer5=L'indentation en C est très importante car on peut mettre des espaces, des tabulations et des retours à la ligne un peu partout.
answer6=On ne peut pas faire de programme C sans commencer par inclure <stdio.h>.
right_answer1=Un programme C est une collection de fonctions qui s'articulent autour d'un main.
right_answer2=L'indentation en C est très importante car on peut mettre des espaces, des tabulations et des retours à la ligne un peu partout.

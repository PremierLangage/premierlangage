title=Les sources et l'exécutable
text==
Selectionner les déclarations justes
==
type=direct
template=../plbank/gift/template/multiplechoices_template.pl
answer1=Un programme C existe sous forme de sources et d'exécutable.
answer2=On peut obtenir les sources à partir de l'exécutable.
answer3=Les sources ont besoin d'être compilées pour être utilisées.
answer4=Les sources sont des fichiers binaires non lisibles par un humain.
answer5=Un ordinateur exploite les sources directement via un interprèteur.    
right_answer1=Un programme C existe sous forme de sources et d'exécutable.
right_answer2=Les sources ont besoin d'être compilées pour être utilisées.

title=La fonction main
text==
Combien de fonction *main* contient un programme C
==
type=direct
template=../plbank/gift/template/multiplechoices_template.pl
answer1=Possiblement aucune
answer2=Autant que possible
answer3=Une et une seule
answer4=Deux, une version sans argument et une autre version avec
right_answer1=Une et une seule

title=Le code C
text==
Selectionner les déclarations justes.
==
type=direct
template=../plbank/gift/template/multiplechoices_template.pl
answer1=Les blocs C s'identifient en allant à la ligne et en rajoutant 4 espaces.
answer2=On peut imbriquer les bloc les uns dans les autres.
answer3=Les instructions se terminent par le caractère ;
answer4=Pour définir une fonction, on ouvre une accolade à la suite de son prototype.
answer5=Quand on a plus d'une instruction, il faut mettre des accolades.
right_answer1=On peut imbriquer les bloc les uns dans les autres.
right_answer2=Les instructions se terminent par le caractère ;
right_answer3=Pour définir une fonction, on ouvre une accolade à la suite de son prototype.
right_answer4=Quand on a plus d'une instruction, il faut mettre des accolades.

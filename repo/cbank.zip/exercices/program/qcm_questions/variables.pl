title=Les variables dans un programme C
text==
Selectionner les déclarations justes
==
type=direct
template=../plbank/gift/template/multiplechoices_template.pl
answer1=Un programme C ne peut pas utiliser plus de 1024 variables.
answer2=Un programme C exploite toujours exactement deux variables : *argc* et *argv*.
answer3=Un programme C peut utiliser autant de variables que possible si la mémoire est suffisante.
answer4=Deux variables peuvent porter le même nom si elle ne sont pas dans les mêmes fonctions.
answer5=Certaines variables n'ont pas de type, ce dernier est déterminé par le compilateur.
right_answer1=Un programme C peut utiliser autant de variables que possible si la mémoire est suffisante.
right_answer2=Deux variables peuvent porter le même nom si elle ne sont pas dans les mêmes fonctions.
